# To_do_list
Here is a simple way to create a to do list using HTML CSS and Javascript
